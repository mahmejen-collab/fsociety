cd (путь)

python main.py
