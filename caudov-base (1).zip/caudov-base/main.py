#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import subprocess
import importlib

# Список нужных библиотек (убираем lxml, он ставится отдельно через pkg)
REQUIRED = [
    "requests",
    "colorama",
    "beautifulsoup4"
]

def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package, "-q"])

def check_and_install():
    missing = []
    for package in REQUIRED:
        try:
            importlib.import_module(package.split("[")[0])
        except ImportError:
            missing.append(package)
    
    if missing:
        print(f" Устанавливаю: {', '.join(missing)}")
        for pkg in missing:
            install(pkg)
        print(" Готово!")
        return True
    else:
        print(" Все библиотеки уже установлены")
        return False

def main():
    # Проверяем и устанавливаем библиотеки
    check_and_install()
    
    # Запускаем tool.py
    current_dir = os.path.dirname(os.path.abspath(__file__))
    tool_path = os.path.join(current_dir, "main", "tool.py")
    
    if os.path.exists(tool_path):
        print(f"\n🔧 Запускаю tool.py...")
        subprocess.run([sys.executable, tool_path])
    else:
        print(f"\n Файл не найден: {tool_path}")
        print("Создайте папку 'main' и положите в неё tool.py")
        input("\nНажми Enter...")

if __name__ == "__main__":
    main()