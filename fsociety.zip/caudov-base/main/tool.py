#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import random
import webbrowser
import time
import requests
import json
import urllib.parse
import shutil

BLUE = '\033[96m'
RED = '\033[91m'
CYAN = '\033[96m'
GREEN = '\033[92m'
RESET = '\033[0m'
BOLD = '\033[1m'

d = "1"
frame = 0

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    global frame
    frame = (frame + 1) % 100
    clear()
    print(f"""{CYAN} {BOLD}
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
XX                                                                          XX
XX   MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM   XX
XX   MMMMMMMMMMMMMMMMMMMMMssssssssssssssssssssssssssMMMMMMMMMMMMMMMMMMMMM   XX
XX   MMMMMMMMMMMMMMMMss'''                          '''ssMMMMMMMMMMMMMMMM   XX
XX   MMMMMMMMMMMMyy''                                    ''yyMMMMMMMMMMMM   XX
XX   MMMMMMMMyy''                                            ''yyMMMMMMMM   XX
XX   MMMMMy''                                                    ''yMMMMM   XX
XX   MMMy'                                                          'yMMM   XX
XX   Mh'                                                              'hM   XX
XX   -                                                                  -   XX
XX                                                                          XX
XX   ::                                                                ::   XX
XX   MMhh.        ..hhhhhh..                      ..hhhhhh..        .hhMM   XX
XX   MMMMMh   ..hhMMMMMMMMMMhh.                .hhMMMMMMMMMMhh..   hMMMMM   XX
XX   ---MMM .hMMMMdd:::dMMMMMMMhh..        ..hhMMMMMMMd:::ddMMMMh. MMM---   XX
XX   MMMMMM MMmm''      'mmMMMMMMMMyy.  .yyMMMMMMMMmm'      ''mmMM MMMMMM   XX
XX   ---mMM ''             'mmMMMMMMMM  MMMMMMMMmm'             '' MMm---   XX
XX   yyyym'    .              'mMMMMm'  'mMMMMm'              .    'myyyy   XX
XX   mm''    .y'     ..yyyyy..  ''''      ''''  ..yyyyy..     'y.    ''mm   XX
XX           MN    .sMMMMMMMMMss.   .    .   .ssMMMMMMMMMs.    NM           XX
XX           N`    MMMMMMMMMMMMMN   M    M   NMMMMMMMMMMMMM    `N           XX
XX            +  .sMNNNNNMMMMMN+   `N    N`   +NMMMMMNNNNNMs.  +            XX
XX              o+++     +++o    M      M    oM++++     +++o              XX
XX                                oo      oo                                XX
XX           oM                 oo          oo                 Mo           XX
XX         oMMo                M              M                oMMo         XX
XX       +MMMM                 s              s                 MMMM+       XX
XX      +MMMMM+            +++NNNN+        +NNNN+++            +MMMMM+      XX
XX     +MMMMMMM+       ++NNMMMMMMMMN+    +NMMMMMMMMNN++       +MMMMMMM+     XX
XX     MMMMMMMMMNN+++NNMMMMMMMMMMMMMMNNNNMMMMMMMMMMMMMMNN+++NNMMMMMMMMM     XX
XX     yMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMy     XX
XX   m  yMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMy  m   XX
XX   MMm yMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMy mMM   XX
XX   MMMm .yyMMMMMMMMMMMMMMMM     MMMMMMMMMM     MMMMMMMMMMMMMMMMyy. mMMM   XX
XX   MMMMd   ''''hhhhh       odddo          obbbo        hhhh''''   dMMMM   XX
XX   MMMMMd             'hMMMMMMMMMMddddddMMMMMMMMMMh'             dMMMMM   XX
XX   MMMMMMd              'hMMMMMMMMMMMMMMMMMMMMMMh'              dMMMMMM   XX
XX   MMMMMMM-               ''ddMMMMMMMMMMMMMMdd''               -MMMMMMM   XX
XX   MMMMMMMM                   '::dddddddd::'                   MMMMMMMM   XX
XX   MMMMMMMM-                                                  -MMMMMMMM   XX
XX   MMMMMMMMM                                                  MMMMMMMMM   XX
XX   MMMMMMMMMy                                                yMMMMMMMMM   XX
XX   MMMMMMMMMMy.                                            .yMMMMMMMMMM   XX
XX   MMMMMMMMMMMMy.                                        .yMMMMMMMMMMMM   XX
XX   MMMMMMMMMMMMMMy.                                    .yMMMMMMMMMMMMMM   XX
XX   MMMMMMMMMMMMMMMMs.                                .sMMMMMMMMMMMMMMMM   XX
XX   MMMMMMMMMMMMMMMMMMss.           ....           .ssMMMMMMMMMMMMMMMMMM   XX
XX   MMMMMMMMMMMMMMMMMMMMNo         oNNNNo         oNMMMMMMMMMMMMMMMMMMMM   XX
XX                                                                          XX
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

    .o88o.                               o8o                .
    888 `"                               `"'              .o8
   o888oo   .oooo.o  .ooooo.   .ooooo.  oooo   .ooooo.  .o888oo oooo    ooo
    888    d88(  "8 d88' `88b d88' `"Y8 `888  d88' `88b   888    `88.  .8'
    888    `"Y88b.  888   888 888        888  888ooo888   888     `88..8'
    888    o.  )88b 888   888 888   .o8  888  888    .o   888 .    `888'
   o888o   8""888P' `Y8bod8P' `Y8bod8P' o888o `Y8bod8P'   "888"      d8'
                                                                .o...P'
                                                                `XER0'
{RESET}""")

def check_password():
    p = input(f"{RED}пароль: {RESET}")
    if p != d:
        print(f"{RED}неверно{RESET}")
        sys.exit()

def leet_convert(text):
    leet_map = {
        'а': 'a', 'б': '6', 'в': '8', 'г': 'r', 'д': 'g',
        'е': 'e', 'ё': 'e', 'ж': 'ж', 'з': '3', 'и': 'u',
        'й': 'ŭ', 'к': 'k', 'л': 'л', 'м': 'm', 'н': 'h',
        'о': '0', 'п': 'n', 'р': 'p', 'с': 'c', 'т': '7',
        'у': 'y', 'ф': 'ф', 'х': 'x', 'ц': 'ц', 'ч': '4',
        'ш': 'w', 'щ': 'ш', 'ъ': 'ъ', 'ы': 'ы', 'ь': 'ь',
        'э': 'e', 'ю': 'ю', 'я': '9'
    }
    result = []
    for ch in text.lower():
        if ch in leet_map:
            result.append(leet_map[ch])
        else:
            result.append(ch)
    return ''.join(result)

def search_internet():
    q = input(f"{BLUE}запрос: {RESET}")
    url = f"https://yandex.ru/search/?text={q}"
    print(f"{BLUE}\nоткрываю браузер...{RESET}")
    webbrowser.open(url)

def generate_person():
    first_names = ['иван', 'петр', 'сергей', 'алексей', 'андрей', 'дмитрий', 'владимир']
    last_names = ['иванов', 'петров', 'сидоров', 'кузнецов', 'смирнов', 'волков']
    patronymic = ['иванович', 'петрович', 'сергеевич', 'алексеевич']
    jobs = ['менеджер', 'инженер', 'бухгалтер', 'водитель', 'программист', 'директор']

    name = random.choice(first_names)
    surname = random.choice(last_names)
    mid = random.choice(patronymic)
    phone = f"+7{random.randint(900, 999)}{random.randint(1000000, 9999999)}"
    street = f"ул. {random.choice(['Ленина', 'Советская', 'Мира', 'Гагарина'])}"
    house = random.randint(1, 150)
    flat = random.randint(1, 200)
    address = f"{street} {house}, кв {flat}"
    job = random.choice(jobs)

    print(f"{BLUE}\nличность:{RESET}")
    print(f"{BLUE}фио: {surname} {name} {mid}{RESET}")
    print(f"{BLUE}телефон: {phone}{RESET}")
    print(f"{BLUE}адрес: {address}{RESET}")
    print(f"{BLUE}должность: {job}{RESET}")

def ip_lookup():
    ip = input(f"{BLUE}введите IP-адрес: {RESET}")
    print(f"{BLUE}\nвыполняется поиск...{RESET}")
    try:
        response = requests.get(f"http://ip-api.com/json/{ip}", timeout=10)
        if response.status_code != 200 or not response.text.strip():
            print(f"{RED}не удалось получить данные{RESET}")
            return
        data = response.json()
        if data.get('status') == 'success':
            lat = data['lat']
            lon = data['lon']
            print(f"{BLUE}\n=== IP ИНФОРМАЦИЯ ==={RESET}")
            print(f"{BLUE}IP: {data['query']}{RESET}")
            print(f"{BLUE}страна: {data['country']}{RESET}")
            print(f"{BLUE}город: {data['city']}{RESET}")
            print(f"{BLUE}координаты: {lat}, {lon}{RESET}")
            print(f"{BLUE}\nоткрываю карту...{RESET}")
            webbrowser.open(f"https://www.google.com/maps?q={lat},{lon}")
        else:
            print(f"{RED}не удалось определить местоположение{RESET}")
    except Exception as e:
        print(f"{RED}ошибка: {e}{RESET}")

def coords_to_map():
    lat = input(f"{BLUE}введите широту: {RESET}")
    lon = input(f"{BLUE}введите долготу: {RESET}")
    print(f"{BLUE}\nоткрываю карту...{RESET}")
    webbrowser.open(f"https://www.google.com/maps?q={lat},{lon}")

def sites_menu():
    print(f"{BLUE}\n=== ВЫБЕРИ САЙТ (ВКЛЮЧИ ВПН) ==={RESET}")
    print(f"{CYAN}1. Детское{RESET}")
    print(f"{CYAN}2. Хентай{RESET}")
    print(f"{CYAN}3. Порно{RESET}")
    print(f"{CYAN}0. Назад{RESET}")
    print()
    choice = input(f"{CYAN}выбери: {RESET}")
    
    if choice == "1":
        webbrowser.open("https://t.me/+oeAzm0bW_pYxZGE5")
        print(f"{BLUE}открываю подожди пару сек...{RESET}")
    elif choice == "2":
        webbrowser.open("https://t.me/+5CcfLKTlsto3NGJi")
        print(f"{BLUE}открываю подожди пару сек...{RESET}")
    elif choice == "3":
        webbrowser.open("https://hot.noodlemagazine.com")
        print(f"{BLUE}открываю подожди пару сек...{RESET}")
    elif choice == "0":
        return
    else:
        print(f"{RED}неверный выбор{RESET}")
    
    input(f"{BLUE}\nнажми enter...{RESET}")

def manual1():
    print(f"{BLUE}\nоткрываю Telegram...{RESET}")
    webbrowser.open("https://t.me/+6OMl-5pr8LkwMjUx")

def manual2():
    print(f"{BLUE}")
    print("ссылка открывается")
    webbrowser.open("https://t.me/VPNNever")

def telega_caudov():
    print(f"{BLUE}\nоткрываю Telegram...{RESET}")
    webbrowser.open("https://t.me/caudov")

def calculator():
    print(f"{BLUE}\n=== КАЛЬКУЛЯТОР ==={RESET}")
    print(f"{CYAN}Доступные операции: + - * /{RESET}")
    print()
    
    try:
        num1 = float(input(f"{BLUE}первое число: {RESET}"))
        op = input(f"{BLUE}операция (+, -, *, /): {RESET}")
        num2 = float(input(f"{BLUE}второе число: {RESET}"))
        
        if op == "+":
            result = num1 + num2
        elif op == "-":
            result = num1 - num2
        elif op == "*":
            result = num1 * num2
        elif op == "/":
            if num2 == 0:
                print(f"{RED}ошибка: деление на ноль{RESET}")
                input(f"{BLUE}\nнажми enter...{RESET}")
                return
            result = num1 / num2
        else:
            print(f"{RED}неверная операция{RESET}")
            input(f"{BLUE}\nнажми enter...{RESET}")
            return
        
        print(f"{GREEN}результат: {num1} {op} {num2} = {result}{RESET}")
        
    except ValueError:
        print(f"{RED}ошибка: введите числа{RESET}")
    
    input(f"{BLUE}\nнажми enter...{RESET}")

def github()
    print(f"{BLUE}\nоткрываю GitHub...{RESET}")
    webbrowser.open("https://github.com/mahmejen-collab/fsociety")

def file_explorer():
    print(f"{BLUE}\n=== ПРОВОДНИК ==={RESET}")
    
    current = os.getcwd()
    
    while True:
        print(f"{CYAN}\nТекущая папка: {current}{RESET}")
        print(f"{CYAN}Содержимое:{RESET}")
        
        try:
            items = os.listdir(current)
            folders = []
            files = []
            
            for item in items:
                item_path = os.path.join(current, item)
                if os.path.isdir(item_path):
                    folders.append(f"📁 {item}")
                else:
                    size = os.path.getsize(item_path)
                    if size < 1024:
                        size_str = f"{size} B"
                    elif size < 1024 * 1024:
                        size_str = f"{size // 1024} KB"
                    else:
                        size_str = f"{size // (1024 * 1024)} MB"
                    files.append(f"📄 {item} ({size_str})")
            
            for f in folders:
                print(f"   {f}")
            for f in files[:20]:
                print(f"   {f}")
            if len(files) > 20:
                print(f"   ... и ещё {len(files) - 20} файлов")
            
            print(f"\n{CYAN}Действия:{RESET}")
            print(f"1. Войти в папку")
            print(f"2. Наверх")
            print(f"3. Открыть в проводнике")
            print(f"4. Создать папку")
            print(f"5. Удалить файл/папку")
            print(f"0. Назад")
            
            choice = input(f"{BLUE}\nвыбери: {RESET}")
            
            if choice == "1":
                name = input(f"{BLUE}имя папки: {RESET}")
                new_path = os.path.join(current, name)
                if os.path.isdir(new_path):
                    current = new_path
                else:
                    print(f"{RED}папка не найдена{RESET}")
            
            elif choice == "2":
                parent = os.path.dirname(current)
                if parent != current:
                    current = parent
                else:
                    print(f"{RED}это корневая папка{RESET}")
            
            elif choice == "3":
                webbrowser.open(current)
                print(f"{GREEN}открываю проводник...{RESET}")
            
            elif choice == "4":
                name = input(f"{BLUE}имя новой папки: {RESET}")
                new_path = os.path.join(current, name)
                try:
                    os.makedirs(new_path)
                    print(f"{GREEN}папка создана{RESET}")
                except Exception as e:
                    print(f"{RED}ошибка: {e}{RESET}")
            
            elif choice == "5":
                name = input(f"{BLUE}имя файла или папки: {RESET}")
                target = os.path.join(current, name)
                if os.path.exists(target):
                    confirm = input(f"{RED}удалить {name}? (да/нет): {RESET}")
                    if confirm.lower() == "да":
                        try:
                            if os.path.isfile(target):
                                os.remove(target)
                            else:
                                shutil.rmtree(target)
                            print(f"{GREEN}удалено{RESET}")
                        except Exception as e:
                            print(f"{RED}ошибка: {e}{RESET}")
                else:
                    print(f"{RED}не найдено{RESET}")
            
            elif choice == "0":
                break
            
        except Exception as e:
            print(f"{RED}ошибка: {e}{RESET}")
            input(f"{BLUE}\nнажми enter...{RESET}")

def main():
    check_password()
    while True:
        banner()
        print(f"{CYAN}{BOLD}1.{RESET} {CYAN}поиск в интернете{RESET}")
        print(f"{CYAN}{BOLD}2.{RESET} {CYAN}смена букв на цифры{RESET}")
        print(f"{CYAN}{BOLD}3.{RESET} {CYAN}генерация личности{RESET}")
        print(f"{CYAN}{BOLD}4.{RESET} {CYAN}вычислить по IP (открыть карту){RESET}")
        print(f"{CYAN}{BOLD}5.{RESET} {CYAN}координаты в картах{RESET}")
        print(f"{CYAN}{BOLD}6.{RESET} {CYAN}порн{RESET}")
        print(f"{CYAN}{BOLD}7.{RESET} {CYAN}мануал по сочному пробиву и прокси серверам{RESET}")
        print(f"{CYAN}{BOLD}8.{RESET} {CYAN}лучший впн{RESET}")
        print(f"{CYAN}{BOLD}9.{RESET} {CYAN}тг автора{RESET}")
        print(f"{CYAN}{BOLD}10.{RESET} {CYAN}калькулятор{RESET}")
        print(f"{CYAN}{BOLD}11.{RESET} {CYAN}проводник{RESET}")
        print(f"{CYAN}{BOLD}12.{RESET} {CYAN}актуальные версии софта{RESET}")
        print(f"{CYAN}{BOLD}0.{RESET} {CYAN}выход{RESET}")
        print()
        choice = input(f"{CYAN}выбери: {RESET}")

        if choice == "1":
            search_internet()
        elif choice == "2":
            text = input(f"{BLUE}текст: {RESET}")
            print(f"{BLUE}результат: {leet_convert(text)}{RESET}")
        elif choice == "3":
            generate_person()
        elif choice == "4":
            ip_lookup()
        elif choice == "5":
            coords_to_map()
        elif choice == "6":
            sites_menu()
        elif choice == "7":
            manual1()
        elif choice == "12":
            github()
        elif choice == "8":
            manual2()
        elif choice == "9":
            telega_caudov()
        elif choice == "10":
            calculator()
        elif choice == "11":
            file_explorer()
        elif choice == "0":
            break
        input(f"{BLUE}\nнажми enter...{RESET}")

if __name__ == "__main__":
    main()
